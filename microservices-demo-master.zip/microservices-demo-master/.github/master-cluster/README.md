# onlineboutique.dev manifests

This directory contains extra deploy manifests for configuring a domain name/static IP to point to an Online Boutique deployment running in GKE. 